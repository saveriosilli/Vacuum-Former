                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:1951311
A6 / A5 / A4 Vacuum Formers by Bantum_Works is licensed under the Creative Commons - Attribution license.
http://creativecommons.org/licenses/by/3.0/

# Summary

A6 / A5 / A4 Vacuum Formers ...

These Vacuum formers are basically an enlarged version of a Vacuum Former made by aether ... ( see Remix Link For Original )  I liked the concept, but wanted a bigger Platen area - so they : 

+ Are made to fit an A6 / A5 / A4 sheet ...
+ Have added extra strength internally ...
+ Require a Hose adaptor to suit ...
+ Held together with Wing Nuts & Screws ...

Easy to make & use ... :)  

Do note a rotor casting option for your moulds can be found here :
http://www.thingiverse.com/thing:2027135

I also had requests for larger machines, so have added two more sizes ( A5 / A4 ) to the original A6 Vacuum former, which are based on a similar concept - but slightly modified to suit duct work entry to the side ... ;)

+ Made to fit an A4 / A5 sheet ( without cutting the sheet ) ...
+ Revised internally ( added stronger ribs / ends ) ...
+ Added a Hose adaptor to suit ...

Made some Alternate A5 layouts to enable more efficient cutting ... ( will see how they turn out )

Cheers, Bantum ...

# How I Designed This

Drawn up in AutoCAD, 3D Modelled in SketchUp, Laser Cut files edited in Illustrator / Corel Draw ...



## Notes :

- Some of the holes in various locations may have wandered off alignment, or vary in size - so may need to check them beforehand ... :(

- The larger A4 print files are preliminary, there may be errors / omissions in them ... :)

- Have also updated the A4 Hose connector STL file as it had to many errors in it ... :/

- Added a template to enable cut-out of Milk cartons for forming on A5 Sheet ( More to come on this )

- Revised Layout for A5 to reduce waste + maximise cut ... ( still need to check it )

- Found the A5 Hose Connector has a weak point, so have added a clamp with extra fixings ( may look at redesigning this later ) for stronger mounting. 

# Assembly

+ Get the Frames cut-out with your preferred size / method ...

+ Print out Hose Mount / clamp as required for the model size you are using ...

+ Take all the Frames & check them to make sure the holes are aligned. ( may need to re-drill them out )

+ Count sink all the relevant bits to suit flush mount Screws ... ( Use the images for a guide ) ... Depending on which way you prefer to have the bolts facing ...

+ Assemble components starting with the back & work your way forward to the platen. 

+ A5 Version can use 3 inners, But will need a slight trimming of top + bottom parts to fit the Duct ... ( Found another work around is to cut a thinner 3/4mm inner layer )


+ Once assembled, do a quick test run to make sure it all works smoothly without any sticky points or loss of suction ...



+ Go forth & multiply - as they say ... :)


Enjoy, Bantum ...




## Notes :

 - I've used some larger screws than necessary ... ( used what I had lying around )

 - The A4/A5 hose connector is designed to slot into the gap, it may need some sealant to make air tight ... ( Have found it does have a weak spot, so will need to be handled carefully )

- For those who have already printed out their duct connector, an alternate fix is to print out the Duct Clamp & glue it to the existing connector ( images to come ) ...

- Depending on which version you choose to make - be sure to get all the right parts together for assembly ...


Tip : I used a hot glue gun to secure parts together, mainly to stop them coming apart, washers falling out, etc. ...




# Edits

- Revised text & layout - Dec 2016.
- Revised CAD layout & added 'Hose Connector' - Dec 2015.

+ Added a A4 Vacuum Former - Feb 2017
+ Revised A4 Drawing for laser cutting ...
+ Added hose Connector ... 
+ Add some more images + Revised files ...

+ Added A5 Vacuum Former - Mar 2017
+ Added a cut-out template for A5 sheets ...
+ More images added ...
+ Revised & added more info / files ...

+ Added alternate A5 Layout ...
+ Add fix for A5 Hose Duct  ...